<?php
header("http://kingbusca.kingkernel.com.br/public/");
?>