<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <?php $__env->startSection("head"); ?>
    <?php echo $__env->yieldSection(); ?>
    <title><?php echo e(env("APP_NAME")); ?></title>
</head>
<body>
    <?php $__env->startSection("body"); ?>
    <?php echo $__env->yieldSection(); ?>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" ></script>
    <?php $__env->startSection("footer"); ?>
    <?php echo $__env->yieldSection(); ?>
</html><?php /**PATH C:\projetos\animes\resources\views/bootstrap/model.blade.php ENDPATH**/ ?>